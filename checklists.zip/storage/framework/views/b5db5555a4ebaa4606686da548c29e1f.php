<?php if (isset($component)) { $__componentOriginal165f8e34452936f6da18fceb86497519 = $component; } ?>
<?php $component = App\View\Components\App::resolve(['title' => 'Usuários Cadastrados'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\App::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('rightBodySection', null, []); ?>  <?php echo $__env->make('components.partials.admin.menu', ['selected' => 'users.index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  <?php $__env->endSlot(); ?>

    <?php if($users->isEmpty()): ?>
        <p class="lead text-center mb-2">Nenhum Usuário Cadastrado</p>
    <?php else: ?>
        <div class="table-responsive mb-2">
            <table class="table table-hover">
                <thead>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name', 'Nome'));?></th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('type', 'Tipo'));?></th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('unity.name', 'Unidade'));?></th>
                </thead>
                <tbody class="table-group-divider">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr onclick="location.assign('<?php echo e(route('admin.users.show', $user->id)); ?>')">
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->type->label()); ?></td>
                            <td><?php echo e($user->unity->name); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    <div class="actions">
        <a class="btn btn-primary rounded-circle p-1" href="<?php echo e(route('admin.users.create')); ?>" style="width: 42px; height: 42px;">
            <i class="bi bi-plus-lg align-middle fs-5"></i>
        </a>
    </div>

    <?php echo e($users->links()); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal165f8e34452936f6da18fceb86497519)): ?>
<?php $component = $__componentOriginal165f8e34452936f6da18fceb86497519; ?>
<?php unset($__componentOriginal165f8e34452936f6da18fceb86497519); ?>
<?php endif; ?>

<?php /**PATH /home/erick/Projects/Checklist/resources/views/users/index.blade.php ENDPATH**/ ?>