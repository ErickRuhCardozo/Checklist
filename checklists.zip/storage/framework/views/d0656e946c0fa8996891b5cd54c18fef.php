<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['selected' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['selected' => '']); ?>
<?php foreach (array_filter((['selected' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/user-menu.css')); ?>">
<?php $__env->stopPush(); ?>

 <?php $__env->slot('rightHeaderSection', null, []); ?> 
    <button class="btn d-md-none p-0 fs-5" type="button" data-bs-toggle="offcanvas" data-bs-target="#menu">
        <i class="bi bi-list"></i>
    </button>
 <?php $__env->endSlot(); ?>

<div class="offcanvas-md offcanvas-end" tabindex="-1" id="menu">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">Menu</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#menu" aria-label="Close"></button>
     </div>
     <div class="offcanvas-body">
        <ul class="list-unstyled menu-list">
            <li>
                <strong>
                    <i class="bi bi-person-fill fs-5 me-2"></i>
                    <span>Usuários</span>
                </strong>
                <ul class="list-unstyled">
                    <a href="<?php echo e(route('admin.users.index')); ?>" <?php if($selected == 'users.index'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                        <i class="bi bi-person-check-fill fs-5 me-1"></i>
                        <span>Usuários Cadastrados</span>
                    </a>
                    <a href="<?php echo e(route('admin.users.create')); ?>" <?php if($selected == 'users.create'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                        <i class="bi bi-person-plus-fill fs-5 me-1"></i>
                        <span>Cadastrar Usuário</span>
                    </a>
                </ul>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Unity::class)): ?>
                <li>
                    <strong>
                        <i class="bi bi-buildings-fill fs-5 me-2"></i>
                        <span>Unidades</span>
                    </strong>
                    <ul class="list-unstyled">
                        <a href="<?php echo e(route('admin.unities.index')); ?>" <?php if($selected == 'unities.index'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                            <i class="bi bi-building-fill-check fs-5 me-1"></i>
                            <span>Unidades Cadastradas</span>
                        </a>
                        <a href="<?php echo e(route('admin.unities.create')); ?>" <?php if($selected == 'unities.create'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                            <i class="bi bi-building-fill-add fs-5 me-1"></i>
                            <span>Cadastrar Unidade</span>
                        </a>
                    </ul>
                </li>
            <?php endif; ?>
            <li>
                <strong>
                    <i class="bi bi-map-fill fs-5 me-2"></i>
                    <span>Ambientes</span>
                </strong>
                <ul class="list-unstyled">
                    <a href="<?php echo e(route('admin.places.index')); ?>" <?php if($selected == 'places.index'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                        <span class="material-symbols-outlined">where_to_vote</span>
                        <span>Ambientes Cadastrados</span>
                    </a>
                    <a href="<?php echo e(route('admin.places.create')); ?>" <?php if($selected == 'places.create'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                        <span class="material-symbols-outlined">add_location</span>
                        <span>Cadastrar Ambiente</span>
                    </a>
                </ul>
            </li>
            <li>
                <strong>
                    <i class="bi bi-clipboard2-check-fill fs-5 me-2"></i>
                    <span>Tarefas</span>
                </strong>
                <ul class="list-unstyled">
                    <a href="<?php echo e(route('admin.tasks.index')); ?>" <?php if($selected == 'tasks.index'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                        <i class="bi bi-clipboard2-data-fill fs-5 me-1"></i>
                        <span>Tarefas Cadastradas</span>
                    </a>
                    <a href="<?php echo e(route('admin.tasks.create')); ?>" <?php if($selected == 'tasks.create'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                        <i class="bi bi-clipboard-plus-fill fs-5 me-1"></i>
                        <span>Cadastrar Tarefa</span>
                    </a>
                </ul>
            </li>
            <li>
                <strong>
                    <i class="bi bi-card-checklist fs-5 me-2"></i>
                    <span>Checklists</span>
                </strong>
                <ul class="list-unstyled">
                    <a href="<?php echo e(route('admin.checklists.index')); ?>" <?php if($selected == 'checklists.index'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                        <i class="bi bi-list-check fs-5 me-1"></i>
                        <span>Checklists Registrados</span>
                    </a>
                </ul>
            </li>
            <li>
                <strong>
                    <i class="bi bi-gear-fill fs-5 me-2"></i>
                    <span>Configurações</span>
                </strong>
                <ul class="list-unstyled">
                    <a href="<?php echo e(route('admin.settings.index')); ?>" <?php if($selected == 'settings.index'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                        <i class="bi bi-gear-fill fs-5 me-1"></i>
                        <span>Suas Configurações</span>
                    </a>
                </ul>
            </li>
        </ul>
     </div>
</div>

<?php /**PATH /home/erick/Projects/Checklist/resources/views/components/partials/admin/menu.blade.php ENDPATH**/ ?>