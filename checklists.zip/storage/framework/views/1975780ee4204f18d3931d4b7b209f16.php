<?php $__env->startPush('scripts'); ?>
    <script>
        function showDeleteDialog() {
            new bootstrap.Modal('#deleteDialog', { toogle: false }).show();
        }
    </script>
<?php $__env->stopPush(); ?>
<div class="modal fade" tabindex="-1" id="deleteDialog">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e($title); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <p><?php echo e($message); ?></p>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form action="<?php echo e($route); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Excluir</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php /**PATH /home/erick/Projects/Checklist/resources/views/components/delete-dialog.blade.php ENDPATH**/ ?>