<div <?php echo e($attributes->merge(['class' => 'form-floating'])); ?>>
    <input type="<?php echo e($type); ?>" class="form-control <?php if(!empty($error)): ?> is-invalid <?php endif; ?>" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>Field" placeholder="<?php echo e($label); ?>" value="<?php echo e($value); ?>" <?php if($required): ?> required <?php endif; ?> <?php if($readonly): ?> readonly <?php endif; ?> <?php if($focus): ?> autofocus <?php endif; ?>>
    <label for="<?php echo e($name); ?>Field">
        <i class="bi bi-<?php echo e($icon); ?> me-1"></i>
        <span><?php echo e($label); ?></span>
    </label>
    <div class="invalid-feedback"><?php echo e($error); ?></div>
</div>

<?php /**PATH /home/erick/Projects/Checklist/resources/views/components/input-field.blade.php ENDPATH**/ ?>