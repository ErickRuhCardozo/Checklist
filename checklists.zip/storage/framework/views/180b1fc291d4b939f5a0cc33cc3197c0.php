<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['selected' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['selected' => '']); ?>
<?php foreach (array_filter((['selected' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/user-menu.css')); ?>">
<?php $__env->stopPush(); ?>

 <?php $__env->slot('rightHeaderSection', null, []); ?> 
    <button class="btn d-md-none p-0 fs-5" type="button" data-bs-toggle="offcanvas" data-bs-target="#menu">
        <i class="bi bi-list"></i>
    </button>
 <?php $__env->endSlot(); ?>

<div class="offcanvas-md offcanvas-end" tabindex="-1" id="menu">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">Olá <?php echo e(auth()->user()->name); ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#menu" aria-label="Close"></button>
     </div>
     <div class="offcanvas-body">
        <ul class="list-unstyled menu-list">
            <li>
                <strong>
                    <i class="bi bi-clipboard-check-fill fs-5 me-2"></i>
                    <span>Checklists</span>
                </strong>
                <ul class="list-unstyled">
                    <a href="<?php echo e(route('employee.checklists.create')); ?>" <?php if($selected == 'checklists.create'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                        <i class="bi bi-clipboard-plus-fill fs-5 me-1"></i>
                        <span>Novo Checklist</span>
                    </a>
                    <a href="<?php echo e(route('employee.checklists.continue')); ?>">
                        <i class="bi bi-repeat fs-5 me-1"></i>
                        <span>Continuar Checklist</span>
                    </a>
                    <a href="<?php echo e(route('employee.checklists.index')); ?>" <?php if($selected == 'checklists.index'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                        <i class="bi bi-clipboard2-pulse-fill fs-5 me-1"></i>
                        <span>Seus Checklists</span>
                    </a>
                </ul>
            </li>
            <li>
                <strong>
                    <i class="bi bi-gear-fill fs-5 me-2"></i>
                    <span>Configurações</span>
                </strong>
                <ul class="list-unstyled">
                    <a href="<?php echo e(route('employee.settings.index')); ?>" <?php if($selected == 'settings.index'): ?> style="background: var(--bs-blue);" <?php endif; ?>>
                        <i class="bi bi-gear-fill fs-5 me-1"></i>
                        <span>Suas Configurações</span>
                    </a>
                </ul>
            </li>
        </ul>
     </div>
</div>

<?php /**PATH /home/erick/Projects/Checklist/resources/views/components/partials/employee/menu.blade.php ENDPATH**/ ?>