<?php if (isset($component)) { $__componentOriginal165f8e34452936f6da18fceb86497519 = $component; } ?>
<?php $component = App\View\Components\App::resolve(['title' => 'Unidade','back' => route('admin.unities.index')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\App::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('rightBodySection', null, []); ?>  <?php echo $__env->make('components.partials.admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginal767b2fe2f313e877004be11b5e91bb94 = $component; } ?>
<?php $component = App\View\Components\InputField::resolve(['label' => 'Nome','icon' => 'buildings-fill','readonly' => true,'value' => $unity->name] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputField::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal767b2fe2f313e877004be11b5e91bb94)): ?>
<?php $component = $__componentOriginal767b2fe2f313e877004be11b5e91bb94; ?>
<?php unset($__componentOriginal767b2fe2f313e877004be11b5e91bb94); ?>
<?php endif; ?>

    <h5 class="mt-3 mb-1">Usuários:</h5>
    <?php if($unity->users->isEmpty()): ?>
        <p class="lead text-center">Nenhum Usuário Nessa Unidade</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="fw-bold">
                    <th>Nome</th>
                    <th>Tipo</th>
                </thead>
                <tbody class="table-group-divider">
                    <?php $__currentLoopData = $unity->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr onclick="location.assign('<?php echo e(route('admin.users.show', $user->id)); ?>?back=<?php echo e(route('admin.unities.show', $unity->id)); ?>')">
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->type->label()); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <h5 class="mt-3 mb-1">Ambientes:</h5>
    <?php if($unity->places->isEmpty()): ?>
        <p class="lead text-center">Nenhum Ambiente Cadastrado Nessa Unidade</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="fw-bold">
                    <th>Nome</th>
                    <th>Tarefas</th>
                </thead>
                <tbody class="table-group-divider">
                    <?php $__currentLoopData = $unity->places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr onclick="location.assign('<?php echo e(route('admin.places.show', $place->id)); ?>?back=<?php echo e(route('admin.unities.show', $unity->id)); ?>')">
                            <td><?php echo e($place->name); ?></td>
                            <td><?php echo e($place->tasks()->count()); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <div class="actions">
        <a class="btn btn-primary rounded-circle p-1" href="<?php echo e(route('admin.unities.edit', $unity->id)); ?>" style="width: 42px; height: 42px;">
            <i class="bi bi-pencil-fill align-middle fs-5"></i>
        </a>
        <a class="btn btn-primary rounded-circle p-1" href="<?php echo e(route('admin.users.create')); ?>?unity=<?php echo e($unity->id); ?>&back=<?php echo e(route('admin.unities.show', $unity->id)); ?>" style="width: 42px; height: 42px;">
            <i class="bi bi-person-plus-fill align-middle fs-5"></i>
        </a>
        <a class="btn btn-primary rounded-circle p-1" href="<?php echo e(route('admin.places.create')); ?>?unity=<?php echo e($unity->id); ?>&back=<?php echo e(route('admin.unities.show', $unity->id)); ?>" style="width: 42px; height: 42px;">
            <span class="material-symbols-outlined">add_location_alt</span>
        </a>
        <a class="btn btn-danger rounded-circle p-1" href="javascript:showDeleteDialog()" style="width: 42px; height: 42px;">
            <i class="bi bi-trash-fill align-middle fs-5"></i>
        </a>
    </div>

    <?php if (isset($component)) { $__componentOriginal10784322522161927068bc5fd6fe9b4d = $component; } ?>
<?php $component = App\View\Components\DeleteDialog::resolve(['title' => 'Excluir Unidade','message' => 'Deseja excluir essa Unidade?','route' => route('admin.unities.destroy', $unity->id)] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('delete-dialog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DeleteDialog::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10784322522161927068bc5fd6fe9b4d)): ?>
<?php $component = $__componentOriginal10784322522161927068bc5fd6fe9b4d; ?>
<?php unset($__componentOriginal10784322522161927068bc5fd6fe9b4d); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal165f8e34452936f6da18fceb86497519)): ?>
<?php $component = $__componentOriginal165f8e34452936f6da18fceb86497519; ?>
<?php unset($__componentOriginal165f8e34452936f6da18fceb86497519); ?>
<?php endif; ?>

<?php /**PATH /home/erick/Projects/Checklist/resources/views/admin/unities/show.blade.php ENDPATH**/ ?>