<?php $__env->startPush('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js" integrity="sha512-CNgIRecGo7nphbeZ04Sc13ka07paqdeTu0WR1IM4kNcpmBAUSHSQX0FslNhTDadL4O5SAGapGt4FodqL8My0mA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        function downloadQrCode() {
            let qrCode = new QRCode(document.getElementById('qrCodeContainer'), { width: 1000, height: 1000 });
            let link = document.createElement('a');
            link.download = '<?php echo e($place->unity->name); ?> - <?php echo e($place->name); ?>';
            qrCode.makeCode('<?php echo e($place->qrcode); ?>');
            link.href = document.querySelector('canvas').toDataURL();
            link.click();
        }
    </script>
<?php $__env->stopPush(); ?>
<?php if (isset($component)) { $__componentOriginal165f8e34452936f6da18fceb86497519 = $component; } ?>
<?php $component = App\View\Components\App::resolve(['title' => 'Ambiente','back' => request()->get('back') ?? route('admin.places.index')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\App::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('rightBodySection', null, []); ?>  <?php echo $__env->make('components.partials.admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginal767b2fe2f313e877004be11b5e91bb94 = $component; } ?>
<?php $component = App\View\Components\InputField::resolve(['label' => 'Nome','icon' => 'geo-alt-fill','readonly' => true,'value' => $place->name] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputField::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal767b2fe2f313e877004be11b5e91bb94)): ?>
<?php $component = $__componentOriginal767b2fe2f313e877004be11b5e91bb94; ?>
<?php unset($__componentOriginal767b2fe2f313e877004be11b5e91bb94); ?>
<?php endif; ?>

    <div class="input-group mb-2">
        <?php if (isset($component)) { $__componentOriginal767b2fe2f313e877004be11b5e91bb94 = $component; } ?>
<?php $component = App\View\Components\InputField::resolve(['label' => 'QR Code','icon' => 'qr-code','readonly' => true,'value' => $place->qrcode] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputField::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal767b2fe2f313e877004be11b5e91bb94)): ?>
<?php $component = $__componentOriginal767b2fe2f313e877004be11b5e91bb94; ?>
<?php unset($__componentOriginal767b2fe2f313e877004be11b5e91bb94); ?>
<?php endif; ?>

        <button class="btn btn-primary" onclick="downloadQrCode()">Baixar</button>
    </div>

    <div class="d-none" id="qrCodeContainer"></div>

    <?php if (isset($component)) { $__componentOriginal767b2fe2f313e877004be11b5e91bb94 = $component; } ?>
<?php $component = App\View\Components\InputField::resolve(['label' => 'Unidade','icon' => 'buildings-fill','readonly' => true,'value' => $place->unity->name] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputField::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal767b2fe2f313e877004be11b5e91bb94)): ?>
<?php $component = $__componentOriginal767b2fe2f313e877004be11b5e91bb94; ?>
<?php unset($__componentOriginal767b2fe2f313e877004be11b5e91bb94); ?>
<?php endif; ?>

    <h5 class="mt-3 text-center">Usuários que podem checar esse Ambiente:</h5>
    <div class="d-flex align-items-center justify-content-center">
        <div class="btn-group" role="group" aria-label="Basic example">
            <?php $__currentLoopData = $allowedUserTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" class="btn btn-primary"><?php echo e($userType->label()); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <h5 class="mt-3 mb-2">Tarefas:</h5>
    <?php if($place->tasks->isEmpty()): ?>
        <p class="lead text-center">Nenhuma Tarefa Cadastrada Nesse Ambiente</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="fw-bold">
                    <th>Título</th>
                    <th>Período</th>
                </thead>
                <tbody class="table-group-divider">
                    <?php $__currentLoopData = $place->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr onclick="location.assign('<?php echo e(route('admin.tasks.show', $task->id)); ?>?back=<?php echo e(route('admin.places.show', $place->id)); ?>')">
                            <td><?php echo e($task->title); ?></td>
                            <td><?php echo e($task->period->label()); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <div class="actions">
        <a class="btn btn-primary rounded-circle p-1" href="<?php echo e(route('admin.places.edit', $place->id)); ?>" style="width: 42px; height: 42px;">
            <i class="bi bi-pencil-fill align-middle fs-5"></i>
        </a>
        <a class="btn btn-primary rounded-circle p-1" href="<?php echo e(route('admin.tasks.create')); ?>?place=<?php echo e($place->id); ?>&back=<?php echo e(route('admin.places.show', $place->id)); ?>" style="width: 42px; height: 42px;">
            <i class="bi bi-clipboard-plus-fill align-middle fs-5"></i>
        </a>
        <a class="btn btn-danger rounded-circle p-1" href="javascript:showDeleteDialog()" style="width: 42px; height: 42px;">
            <i class="bi bi-trash-fill align-middle fs-5"></i>
        </a>
    </div>

    <?php if (isset($component)) { $__componentOriginal10784322522161927068bc5fd6fe9b4d = $component; } ?>
<?php $component = App\View\Components\DeleteDialog::resolve(['title' => 'Excluir Ambiente','message' => 'Deseja excluir esse Ambiente?','route' => route('admin.places.destroy', $place->id)] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('delete-dialog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DeleteDialog::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10784322522161927068bc5fd6fe9b4d)): ?>
<?php $component = $__componentOriginal10784322522161927068bc5fd6fe9b4d; ?>
<?php unset($__componentOriginal10784322522161927068bc5fd6fe9b4d); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal165f8e34452936f6da18fceb86497519)): ?>
<?php $component = $__componentOriginal165f8e34452936f6da18fceb86497519; ?>
<?php unset($__componentOriginal165f8e34452936f6da18fceb86497519); ?>
<?php endif; ?>

<?php /**PATH /home/erick/Projects/Checklist/resources/views/places/show.blade.php ENDPATH**/ ?>