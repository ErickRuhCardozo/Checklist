<div <?php echo e($attributes->merge(['class' => 'form-floating'])); ?>>
    <select class="form-select" id="<?php echo e($name); ?>Field" name="<?php echo e($name); ?>" <?php if($required): ?> required <?php endif; ?>>
        <option class="d-none" value=""><?php echo e($placeholder); ?></option>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
                value="<?php echo e($option['value']); ?>"
                <?php if($option['label'] == $selectedLabel || $option['value'] == $selectedValue): ?>
                    selected
                <?php endif; ?>><?php echo e($option['label']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <label for="<?php echo e($name); ?>Field">
        <i class="bi bi-<?php echo e($icon); ?> me-1"></i>
        <span><?php echo e($label); ?></span>
    </label>
</div>

<?php /**PATH /home/erick/Projects/Checklist/resources/views/components/select-field.blade.php ENDPATH**/ ?>